const config = {
  rtl: false,
  mode: 'light',
  loggedIn: false,
};

export default config;
